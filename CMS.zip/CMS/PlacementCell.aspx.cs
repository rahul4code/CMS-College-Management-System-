﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PlacementCell : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void UploadBtn_Click(object sender, EventArgs e)
    {

        if (fu.HasFile == true)
        {
            string file = fu.FileName;
            string aaa = file.Substring(file.LastIndexOf('.'));
            if (aaa.Equals(".exe") || aaa.Equals(".java"))
            {
                lb1.Text = "not allowed";
            }
            else
            {
                fu.SaveAs(MapPath("~/CvUpload/" + fu.FileName));
                lb1.Text = "File Upload Successfully on server";
            }
        }
        else

            lb1.Text = "Blank File Not Allowed";
    }
}
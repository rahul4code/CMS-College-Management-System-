﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admision_form : System.Web.UI.Page
{
    dbmanager dbm = new dbmanager();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string q = "insert into admissionform values('" + TextBox2.Text + "','" + TextBox3.Text + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox5.Text + "','" + TextBox4.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + DropDownList2.SelectedItem.Text + "','" + RadioButtonList1.SelectedItem.Text + "','" + DropDownList3.SelectedItem.Text + "','"+TextBox1.Text+"')";
        bool j = dbm.insertupdatedelete(q);
        if (j == true)
        {
            Response.Write("<script>alert(Admission Successful'')</script>");
            q = "Select * from admission where remail='" + TextBox2.Text + "'";
            DataTable dt = new DataTable();
            dt = dbm.ReadbulkData(q);
            TextBox8.Text = dt.Rows[0][0].ToString();
        }
        else
        {

            Response.Write("<script>alert('Admission failed')</script>");
        }
   }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile == true)

        {
            FileUpload1.SaveAs(MapPath("~/upload/"+FileUpload1.FileName));
            Label1.Text="File Uploaded";
        }

                else
            {
              Label1.Text="Blank Document";
            }
        }
    }


 
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Signin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_signup_Click(object sender, EventArgs e)
    {
         string name = txtuser.Text;
        string password = txtpwd.Text;
        string qry = "select * from Admin_id where Admin_Name='"+name+"' and Admin_Pwd='"+password+"'";
        Databasemanager dm=new Databasemanager();
         DataTable dt = new DataTable();
        dt = dm.ReadBulkData(qry);
        if (dt.Rows.Count > 0)
        {
            Session["txtuser"] = txtuser.Text;
            Response.Redirect("http://localhost:9592/CollegeManagement1/AdminHome.aspx");
        }
        else
        {
            Response.Write("<script>alert('Invalid Admin Name and Password')</script>");
        }
    }
}
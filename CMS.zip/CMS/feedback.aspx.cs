﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class feedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    Dbmanager dm = new Dbmanager();
    protected void btn_Click(object sender, EventArgs e)
    {
        string query = "insert into FEEDBACK(feedback,name,email,review)values('" + rb1.SelectedValue + "','" + tname.Text + "','" + tmail.Text + "','" + treview.Text + "')";
        if (dm.insertupdatedelete(query))
        {
            Response.Write("<script>alert('Thank you for your suggestion')</script>");
        }
        else
        {
            Response.Write("<script>alert('Sorry!! Bad Luck')</script>");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SignIn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn1_Click(object sender, EventArgs e)
    {
        string n = txtname.Text;
        string p = txtpwd.Text;
        string qry = "select * from Admin_id where Admin_Name='"+n+"' and Admin_Pwd='"+p+"'";
        Databasemanager dm=new Databasemanager();
         DataTable dt = new DataTable();
        dt = dm.ReadBulkData(qry);
        if (dt.Rows.Count > 0)
        {
            Response.Write("<script>alert('Welcome Admin...')</script>");
            Response.Redirect("http://localhost:36184/collegemgmt/AdminHome.aspx");
        }
        else
        {
            Response.Write("<script>alert('Invalid Admin Name and Password')</script>");
        }
    }
}
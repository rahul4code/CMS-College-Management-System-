﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UploadExamSchedule : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        txtsub.Text = "";
        if (fu.HasFile == true)
        {
            string fname, qry;
            fname = fu.FileName;
            fu.SaveAs(MapPath("~/EXAM SCHEME/" + fname));
            qry = "insert into DatesheetUpload(Subject_Name,File_Name,Upload_Date) values('" + txtsub.Text + "', '" + fname + "','" + DateTime.Now + "')";
            Databasemanager dm = new Databasemanager();
            bool j = dm.insertupdatedelete(qry);
            if (j == true)
            {
                GridView1.DataBind();
                lblmsg.Text = "Exam Date-sheet Uploaded Successfuly";
            }
            else
            {
                lblmsg.Text = "Exam Date-sheet Not Uploaded Successfuly";
            }
        }
        else
        {
            lblmsg.Text = "No file selected";
        }
    }
}
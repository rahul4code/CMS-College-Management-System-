﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class loginpage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Click(object sender, EventArgs e)
    {
        SqlConnection con=new SqlConnection(@"Data Source=LENOVO-PC\SQLEXPRESS;Initial Catalog=College_management;Integrated Security=True");
        con.Open();
        SqlCommand cmd = new SqlCommand("select userid,Password from register where userid='" + textuser.Text + "' AND Password='" + textpass.Text + "'",con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds, "register");
        if (ds.Tables["register"].Rows.Count>0)
        {
            lblmsg.Text = "WELCOME";
        }
        else
        {
            lblmsg.Text = "invalid userid and password";
        }
        con.Close();
    }

}

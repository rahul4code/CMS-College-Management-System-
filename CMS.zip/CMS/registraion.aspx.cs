﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class registraion : System.Web.UI.Page
{
    dbmanager db = new dbmanager();
    encryptdecrypt ed = new encryptdecrypt();
    CapchaCodeGenerator cp = new CapchaCodeGenerator();
    string capcode1;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == false)
        {
            C1.Visible = false;
            capcode1 = CapchaCodeGenerator.GetCaptcha();
            Label1.Text = capcode1;
        }
        
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
{
    capcode1 = CapchaCodeGenerator.GetCaptcha();
    Label1.Text = capcode1;
}
    protected void Button2_Click(object sender, EventArgs e)
    {
        string epass;
         capcode1 = CapchaCodeGenerator.GetCaptcha();
        if(capcode1==TextBox11.Text)
         epass = ed.encryptmydata(t8.Text);
        string q = "insert into registration values('" + t1.Text + "','" + t2.Text + "','" + t3.Text + "','" + t4.Text + "','" + t10.Text + "','" + RadioButtonList1.SelectedItem.Text + "','" + t5.Text + "','" + t6.Text + "','" + t7.Text + "','" + epass + "')";
        bool j = db.insertupdatedelete(q);
        if (j == true)
            Response.Write("<script>alert('Registered')</script>");
        else

            Response.Write("<script>alert('ReRegister')</script>");

        if (Label1.Text == TextBox11.Text)
        {
            Label1.Text = "captcha matched";
        }
        else
        {
            Label1.Text = "captcha not matched";
        }
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (C1.Visible == false)
        {
            C1.Visible = true;
        }
        else
        {
            C1.Visible = false;
        }
    }

    protected void C1_SelectionChanged(object sender, EventArgs e)
    {
        t10.Text = C1.SelectedDate.ToString("d");
    }
    protected void C1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date > DateTime.Now.Date)
        {
            e.Day.IsSelectable = false;
            e.Cell.Font.Size = 14;
        }
    }
  
}

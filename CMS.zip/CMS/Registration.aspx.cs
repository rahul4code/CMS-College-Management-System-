﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Registration : System.Web.UI.Page
{
    string capcode1;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            capcode1 = CapchaCodeGenerator.GetCapCode();
            lblrefresh.Text = capcode1;
        }
    }
    public bool insertrecord()
    {
        SqlConnection conn = new SqlConnection(@"Data Source=LENOVO-PC\SQLEXPRESS;Initial Catalog=College_management;Integrated Security=True");
        conn.Open();
        string q = "insert into register(First_name,Last_name,Phone_no,Address,Gender,Email,userid,Password) values('" + First.Text + "','" + Second.Text + "','" + Third.Text + "','" + Address.Text + "','" + dp1.SelectedValue + "','" + Email.Text + "','" + user.Text + "','" + pass.Text + "')";

        SqlCommand cmd = new SqlCommand(q, conn);
        int i = cmd.ExecuteNonQuery();
        if (i > 0)
        {
            return true;
         }
        else
        {
            return false;
            }
    }


    protected void btn_Click(object sender, EventArgs e)
    {

        if (security.Text == lblrefresh.Text)
        {
            if(insertrecord())
            {
                lblverify.Text = "";
                Response.Write("<script>alert('Successfully Registered')</script>");
             }
        else
            {
                Response.Write("<script>alert('Unsuccessfully Registration</script>");
            }

        }
        else
        {
            lblverify.Text = "Captcha Not Matched";
        }
    }

    protected void btnrefresh_Click(object sender, EventArgs e)
    {
        capcode1 = CapchaCodeGenerator.GetCapCode();
        lblrefresh.Text = capcode1;
    }
  

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

public partial class password : System.Web.UI.Page
{
    dbmanager db = new dbmanager();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == null )
        {
            Label1.Text = "Enter E-mail Id";
        }
        else
        {
            getPassword();
        }
    }
    public void getPassword()
    {
        string qry = "Select * from registration where email=@email";
        SqlParameter[] data = new SqlParameter[1];
        data[0] = new SqlParameter("@email", TextBox1.Text);
        dbmanager obj = new dbmanager();
        DataSet ds = new DataSet();
        ds = obj.selectCommand(qry, data);
        if (ds != null && ds.Tables[0].Rows.Count > 0)
        {
            Label1.Text = ds.Tables["temp"].Rows[0].ItemArray[1].ToString();
            Label1.Visible = false;
            send_mail();
            Label2.ForeColor = System.Drawing.Color.Green;
            Label2.Text = "mail send sucessfully...Please login to your Account";

            Label2.Font.Bold = true;
        }
        else
        {
            Label2.Text = "Details not found in DB";
            Label2.ForeColor = System.Drawing.Color.Red;
            Label2.Font.Bold = true;
        }
    }
    protected void send_mail()
    {
        try
        {
            SmtpClient obj_smtp = new SmtpClient();
            obj_smtp.Credentials = new System.Net.NetworkCredential("nosheenawazish@gmail.com", "1234");
            //Use valid EmailID & Password
            obj_smtp.Port = 587;
            obj_smtp.Host = "smtp.gmail.com";
            obj_smtp.EnableSsl = true;
            MailMessage objMail = new MailMessage();
            objMail.From = new MailAddress("nosheenawazish@gmail.com", "Development Cell", System.Text.Encoding.UTF8);
            objMail.To.Add(TextBox1.Text.Trim());
            objMail.Subject = "Support Desk-Help ";
            objMail.Body = "Hii \n Your Password is " + Label1.Text;
            obj_smtp.Send(objMail);
        }
        catch
        {
            Label2.Text = "Network not accessible. Please try again!!!";
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("loginn.aspx");
    }
}
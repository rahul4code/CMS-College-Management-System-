﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class loginn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string email, pwd;
        email = TextBox1.Text;
        pwd = TextBox2.Text;
        string query = "select * from registration where email= '" + email + "' and password='" + pwd + "'";
        dbmanager dm = new dbmanager();
        DataTable dt = new DataTable();
        dt = dm.ReadbulkData(query);
        if (dt.Rows.Count > 0)
        {
            Response.Redirect("");
        }
        else
        {
            Response.Write("<script>alert('Your Email Id or Password is Invalid')</script>");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for encryptdecrypt
/// </summary>
public class encryptdecrypt
{
	public encryptdecrypt()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string encryptmydata(string str)
    {
        string newstring = "";
        int ascii;
        foreach (char ch in str)
        {
            ascii = ch;
            ascii = ascii + 5;
            newstring=newstring +(char)ascii;

        }
        return newstring;
    }
    public string decryptmydata(string str)
    {
        string newstring = "";
        int ascii;
        foreach (char ch in str)
        {
            ascii = ch;
            ascii = ascii - 5;
            newstring = newstring + (char)ascii;
        }
        return newstring;
    }
}
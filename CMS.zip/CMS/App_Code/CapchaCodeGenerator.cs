﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CapchaCodeGenerator
/// </summary>
public class CapchaCodeGenerator
{
	public CapchaCodeGenerator()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static string GetCapCode()
    {
        string capcode = "";
        Random r = new Random();
        char ch;
        ch = (char)r.Next(65, 90);
        capcode = capcode + ch;
        ch = (char)r.Next(65, 90);
        capcode = capcode + ch;
        ch = (char)r.Next(48, 57);
        capcode = capcode + ch;
        ch = (char)r.Next(48, 57);
        capcode = capcode + ch;
        ch = (char)r.Next(97, 122);
        capcode = capcode + ch;
        ch = (char)r.Next(97, 122);
        capcode = capcode + ch;
        return capcode;
    }
    

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Mail;

/// <summary>
/// Summary description for emailsender
/// </summary>
public class emailsender
{
	public emailsender()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public bool Gmailsender(string sendto,string sub,string body)
    {
        SmtpClient client = new SmtpClient();
        MailMessage mm = new MailMessage();
        try
        {// setting mail attribute
            NetworkCredential stmpcreds = new NetworkCredential("cms.6members@gmail.com", "cms123456");
            client.Host = "smtp.gmail.com";
            client.Port = 587;//http port no. is 587
            client.UseDefaultCredentials = false;
            client.Credentials = stmpcreds;
            client.EnableSsl = true;
            //convert string to email address
            MailAddress to = new MailAddress(sendto);
            MailAddress from = new MailAddress("cms.6members@gmail.com");
            //setup msg setting
            mm.Subject = sub;
            mm.Body = body;
            mm.From = from;
            mm.To.Add(to);
            //send mail
            client.Send(mm);
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }
}
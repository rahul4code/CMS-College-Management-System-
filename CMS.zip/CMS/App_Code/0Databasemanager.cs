﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Databasemanager
/// </summary>
public class Databasemanager
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-IJB4N0U\SQLEXPRESS;Initial Catalog=CollegeMgmt;Integrated Security=True");

	public Databasemanager()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public bool insertupdatedelete(string command)
    {
        SqlCommand cmd = new SqlCommand(command, con);
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        int res = cmd.ExecuteNonQuery();
        con.Close();
        if (res >0)
            return true;
        else
            return false;
    }
    public DataTable ReadBulkData(string command)
    {
        SqlDataAdapter da = new SqlDataAdapter(command,con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Dbmanager
/// </summary>
public class Dbmanager
{
    SqlConnection con = new SqlConnection(@"Data Source=LENOVO-PC\SQLEXPRESS;Initial Catalog=College_management;Integrated Security=True");
	public Dbmanager()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public bool insertupdatedelete(string query)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(query,con);
        if (cmd.ExecuteNonQuery() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
        con.Close();
    }
}